﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[6];
            Random rand = new Random();
            int sayi;
            //createDataSet();
            int i,j ,x,y;
            int count = 0;
            for (i = 0; i < 1000; i++)
            {
                for (x = 0; x < arr.Length; x++)
                {
                    sayi = rand.Next(1, 49);
                    arr[x] = sayi;
                    for (y = 0; y < x; y++)
                    {
                        if (x == y)
                        {
                            break;
                        }

                        while (arr[x] == arr[y])
                        {
                            sayi = rand.Next(1, 49);
                            arr[x] = sayi;
                        }
                    }
                    
                }

                for (x = 0; x < arr.Length-1; x++)
                {
                    for (y = 0; y < arr.Length - x - 1; y++)
                    {
                        if (arr[y] > arr[y + 1])
                        {
                            int temp = arr[y];
                            arr[y] = arr[y + 1];
                            arr[y + 1] = temp;
                        }
                    }
                }

                if(arr[4] == arr[5]) // aynı olan sayıları kontrol ediyor.
                {
                    count++;
                    Console.WriteLine("----------");
                }

                if (arr[3] == arr[4]) // aynı olan sayıları kontrol ediyor.
                {
                    count++;
                    Console.WriteLine("----------");
                }

                if (arr[2] == arr[3]) // aynı olan sayıları kontrol ediyor.
                {
                    count++;
                    Console.WriteLine("----------");
                }

                if (arr[1] == arr[2]) // aynı olan sayıları kontrol ediyor.
                {
                    count++;
                    Console.WriteLine("----------");
                }

                if (arr[0] == arr[1]) // aynı olan sayıları kontrol ediyor.
                {
                    count++;
                    Console.WriteLine("----------");
                }



                for (j = 0; j < arr.Length; j++)
                {
                    if (j == arr.Length - 1)
                    {
                        Console.Write($"{arr[j]}");
                    }
                    else
                    {
                        Console.Write($"{arr[j]},");
                    }
                    

                }
                createDataSet(arr);
                Console.WriteLine();
                
            }

            Console.WriteLine($"count: {count}");
            Console.ReadKey();
        }


        private static void createDataSet(int []arr)
        {
            Directory.CreateDirectory(@"C:\Data_Mining_Example_Data");
            string path = @"C:\Data_Mining_Example_Data\Ltrain.txt";
            string virgul = ",";
            string no = "NO\n";

            // Set a variable to the Documents path.
            string docPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            // Append text to an existing file named "WriteLines.txt".
            using (StreamWriter outputFile = new StreamWriter(Path.Combine(docPath, "WriteLines.txt"), true))
            {
                //outputFile.WriteLine("Fourth Line");
                outputFile.Write(arr[0]);
                outputFile.Write(virgul);
                outputFile.Write(arr[1]);
                outputFile.Write(virgul);
                outputFile.Write(arr[2]);
                outputFile.Write(virgul);
                outputFile.Write(arr[3]);
                outputFile.Write(virgul);
                outputFile.Write(arr[4]);
                outputFile.Write(virgul);
                outputFile.Write(arr[5]);
                outputFile.Write(virgul);
                outputFile.Write(no);
                outputFile.Close();

            }
        }
    }
}
